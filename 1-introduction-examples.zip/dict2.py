
# coding: utf-8

# In[ ]:

text = "hello I am happy. Are you?"


# In[ ]:

# libraries for: regular expressions, file I/O
import re
import sys
import unicodecsv


# In[ ]:

def preProcess(text):
    print "original:", text
    # sentence segmentation - assume already done
    pass
    # word tokenisation
    text = re.sub(r"(\w)([.,;:!?'\"”\)])", r"\1 \2", text)
    text = re.sub(r"([.,;:!?'\"“\(])(\w)", r"\1 \2", text)
    print "tokenising:", text
    tokens = re.split(r"\s+",text)
    # normalisation
    text = re.sub(r"(\S)\1\1+",r"\1\1\1", text)
    tokens = [t.lower() for t in tokens]
    return tokens


# In[ ]:

print preProcess(text)


# In[ ]:

# load an external dictionary
sentimentDict = {}
with open('sentiment.csv', 'rb') as f:
    reader = unicodecsv.reader(f, encoding='utf-8')
    for line in reader:
        sentimentDict[line[0]] = float(line[1])
print sentimentDict


# In[ ]:

def getSentiment(word):
    try:
        return sentimentDict[word]
    except KeyError:
        return 0.0


# In[ ]:

def analyseSentiment(text):
    words = preProcess(text)
    print "words:", words
    scores = [getSentiment(w) for w in words]
    print "scores", scores
    return sum(scores)


# In[ ]:

s = analyseSentiment(text)
print "sentiment = ", s


# In[ ]:



